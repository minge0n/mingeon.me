import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync,spawnSync} from 'node:child_process';
const root=process.cwd(),base=path.join(root,'backups/20261102-193800-stock'),out=path.join(root,'analysis/apply-gsi/preflight'),manifest=JSON.parse(fs.readFileSync(base+'/manifest.json')),plan=JSON.parse(fs.readFileSync('analysis/install-plan/application-manifest.json'));
fs.mkdirSync(out,{recursive:true,mode:0o700});const stateFile=path.join(root,'analysis/apply-gsi/status.json');const sha=p=>{const h=crypto.createHash('sha256'),fd=fs.openSync(p,'r'),b=Buffer.alloc(8*1024*1024);let n;try{while((n=fs.readSync(fd,b,0,b.length,null))>0)h.update(b.subarray(0,n));}finally{fs.closeSync(fd)}return h.digest('hex')};
const state={startedAt:new Date().toISOString(),stage:'preflight',deviceWritesPerformed:false,readbacks:[]};const save=()=>fs.writeFileSync(stateFile,JSON.stringify(state,null,2));save();
try{
 if(plan.approvedChoice!=='초기화 포함 설치 진행'||!plan.independentReview?.passed||plan.independentReview.reviewedSuperSHA256!==plan.writeOrder.find(p=>p.name==='super').sha256)throw Error('Scope approval or final review missing');
 const usb=execFileSync('/usr/sbin/ioreg',['-p','IOUSB','-l','-w','0'],{encoding:'utf8'});if(!usb.includes('QUSB_BULK_CID:043A_SN:TARGET_EDL_ID@')||(usb.match(/\+-o QUSB_BULK/g)||[]).length!==1)throw Error('Expected exactly the intended EDL device');
 for(const t of plan.writeOrder){if(fs.lstatSync(t.file).isSymbolicLink()||fs.statSync(t.file).size!==t.bytes||sha(t.file)!==t.sha256)throw Error('Prepared image changed: '+t.name);}
 for(const name of ['misc','smraw','metadata','vbmeta_b','vbmeta_system_b','boot_b','init_boot_b','vendor_boot_b','dtbo_b','recovery_b','super']){
  const p=manifest.partitions.find(p=>p.name===name);if(!p||p.offsetBytes%4096||p.sizeBytes%4096)throw Error('Invalid target geometry '+name);
  const image=path.join(out,name+'.img'),log=path.join(out,name+'.log');if(fs.existsSync(image)||fs.existsSync(log))throw Error('Refusing to overwrite preflight evidence '+name);
  state.stage='reading_'+name;save();console.log('Reading '+name+' ('+p.sizeBytes+' bytes) from LUN '+p.lun);
  const logfd=fs.openSync(log,'wx',0o600);let r;try{r=spawnSync(path.join(root,'edl/.venv312/bin/edl'),['r',name,image,'--loader='+path.join(root,'firehose.elf'),'--memory=ufs','--lun='+p.lun],{cwd:root,stdio:['ignore',logfd,logfd],timeout:600000});}finally{fs.closeSync(logfd);}
  if(r.error||r.status!==0||!fs.existsSync(image)||fs.statSync(image).size!==p.sizeBytes)throw Error('Read failed '+name+': '+(r.error||r.status));fs.chmodSync(image,0o600);
  const logtext=fs.readFileSync(log,'utf8'),match=logtext.match(/Dumped sector (\d+) with sector count (\d+)/);if(!match||Number(match[1])!==p.offsetBytes/4096||Number(match[2])!==p.sizeBytes/4096)throw Error('Live GPT geometry differs '+name);
  const digest=sha(image),expected=name==='super'?plan.expectedOriginalSuperSHA256:p.sha256;
  if(expected&&digest!==expected&&name!=='misc')throw Error('Live image differs from original: '+name+' ('+digest+')');
  let extra={};if(name==='misc'){const b=fs.readFileSync(image),command=b.subarray(0,32).toString('ascii').replace(/\0.*$/s,''),args=b.subarray(64,832).toString('ascii').replace(/\0.*$/s,'');if(!['','boot-fastboot'].includes(command)||args)throw Error('Unexpected pending boot/recovery operation');if(b.readUInt32LE(32769)!==0x56740ab0||b[32773]!==0||b[32774]!==1)throw Error('Unexpected Virtual A/B state');extra={bootCommand:command,recoveryArgs:args,virtualABMergeStatus:0,sourceSlot:1};}
  state.readbacks.push({name,lun:p.lun,startSector:p.offsetBytes/4096,sectorCount:p.sizeBytes/4096,file:image,bytes:p.sizeBytes,sha256:digest,matchesOriginal:expected?digest===expected:null,...extra});save();console.log('Verified '+name+': '+digest);
 }
 state.stage='preflight_passed';state.completedAt=new Date().toISOString();save();fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(state,null,2));console.log('All pre-write reads and immutable firmware comparisons passed. No device writes performed.');
}catch(e){state.stage='preflight_blocked';state.error=e.message;save();console.error(e.stack||e.message);process.exitCode=1;}
