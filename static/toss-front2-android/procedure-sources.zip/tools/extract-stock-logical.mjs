import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve('backups/20261102-193800-stock');
const layout=JSON.parse(fs.readFileSync(path.join(root,'analysis/super/layout.json')));
const copy=layout.copies.find(c=>c.slot===1&&c.copy==='primary'&&c.valid);
if(!copy)throw Error('No verified slot-1 metadata');
const output=path.join(root,'analysis/logical-slot-b');fs.mkdirSync(output,{recursive:true});
const raw=path.join(root,'raw/ufs.bin.lun0');const source=fs.openSync(raw,'r');const sourceBytes=fs.fstatSync(source).size;
const buffer=Buffer.alloc(8*1024*1024);const manifest=[];
try {
 for(const p of copy.partitions.filter(p=>p.name.endsWith('_b')&&!p.name.includes('-cow'))){
  const dest=path.join(output,p.name+'.img');
  if(fs.existsSync(dest))throw Error('Refusing to overwrite '+dest);
  const out=fs.openSync(dest,'wx',0o600);const hash=crypto.createHash('sha256');let position=0;
  try {
   for(const e of p.extents){
    let left=e.sectors*512;const start=layout.superOffsetBytes+e.targetSector*512;
    if(e.type!==0||e.blockDevice!==0||start<layout.superOffsetBytes||start+left>layout.superOffsetBytes+layout.superSizeBytes||start+left>sourceBytes)throw Error('Unsupported or out-of-bounds extent');
    let offset=start;while(left){const take=Math.min(left,buffer.length),n=fs.readSync(source,buffer,0,take,offset);if(n!==take)throw Error('Short backup read');let done=0;while(done<n)done+=fs.writeSync(out,buffer,done,n-done,position+done);hash.update(buffer.subarray(0,n));position+=n;offset+=n;left-=n;}
   }
   if(position!==p.sizeBytes)throw Error('Logical size mismatch');fs.fsyncSync(out);
  }finally{fs.closeSync(out);}
  const r={name:p.name,bytes:position,sha256:hash.digest('hex'),image:dest};manifest.push(r);console.log(JSON.stringify(r));
 }
}finally{fs.closeSync(source);}
fs.writeFileSync(path.join(output,'extraction-manifest.json'),JSON.stringify({source:raw,metadataSlot:1,readOnlySource:true,images:manifest},null,2));
const verify=path.join(root,'analysis/stock-b-chain');fs.mkdirSync(verify,{recursive:true});
const aliases={vbmeta:'vbmeta_b',vbmeta_system:'vbmeta_system_b',boot:'boot_b',init_boot:'init_boot_b',vendor_boot:'vendor_boot_b',dtbo:'dtbo_b',recovery:'recovery_b'};
for(const [alias,name] of Object.entries(aliases)){const dst=path.join(verify,alias+'.img'),src=path.join(root,'partitions',name+'.img');if(!fs.existsSync(src))throw Error('Missing physical image '+src);if(!fs.existsSync(dst))fs.symlinkSync(path.relative(verify,src),dst);}
for(const p of manifest){const dst=path.join(verify,p.name.replace(/_b$/,'')+'.img');if(!fs.existsSync(dst))fs.symlinkSync(path.relative(verify,p.image),dst);}
console.log('Read-only source extraction complete; AVB aliases prepared.');
