import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';

process.umask(0o077);
const root = '/path/to/toss-front2';
const backup = path.resolve(process.argv[2] || '');
if (!backup.startsWith(path.join(root, 'backups') + path.sep)) throw Error('Unexpected backup directory');
const sectorSize = 4096;
const py = path.join(root, 'edl/.venv312/bin/python');
const avb = path.join(root, 'tools/avb/avbtool.py');
const readExit = fs.readFileSync(path.join(backup, 'logs/full-read.exit-code'), 'utf8').trim();
if (readExit !== '0') throw Error('The raw read did not finish successfully');
const initialGPT = fs.readFileSync(path.join(backup, 'logs/initial-gpt.txt'), 'utf8');
const expected = [...initialGPT.matchAll(/Parsing Lun (\d+):[\s\S]*?Total disk size:(0x[0-9a-f]+)/gi)]
  .map(m => ({ lun: Number(m[1]), size: Number(BigInt(m[2])) }));
if (expected.length !== 6) throw Error('Expected six LUNs from the captured GPT');

function crc32(buf) {
  let crc = 0xffffffff;
  for (const byte of buf) {
    crc ^= byte;
    for (let b = 0; b < 8; b++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function readExact(fd, offset, length) {
  const b = Buffer.alloc(length);
  let n = 0;
  while (n < length) {
    const got = fs.readSync(fd, b, n, length - n, offset + n);
    if (!got) throw Error(`Short read at ${offset + n}`);
    n += got;
  }
  return b;
}
function number64(buf, offset) {
  const value = Number(buf.readBigUInt64LE(offset));
  if (!Number.isSafeInteger(value)) throw Error('Unsafe GPT offset');
  return value;
}
function readGPT(fd, headerLBA) {
  const block = readExact(fd, headerLBA * sectorSize, sectorSize);
  if (block.toString('ascii', 0, 8) !== 'EFI PART') throw Error('Invalid GPT signature');
  const size = block.readUInt32LE(12);
  if (size < 92 || size > sectorSize) throw Error('Invalid GPT header size');
  const h = Buffer.from(block.subarray(0, size));
  const headerCRC = h.readUInt32LE(16);
  h.writeUInt32LE(0, 16);
  if (crc32(h) !== headerCRC) throw Error('GPT header CRC mismatch');
  const currentLBA = number64(block, 24);
  if (currentLBA !== headerLBA) throw Error('GPT header LBA mismatch');
  const otherLBA = number64(block, 32);
  const entriesLBA = number64(block, 72);
  const count = block.readUInt32LE(80);
  const entrySize = block.readUInt32LE(84);
  if (!count || count > 4096 || entrySize < 128 || entrySize > 4096) throw Error('Invalid GPT entry dimensions');
  const entries = readExact(fd, entriesLBA * sectorSize, count * entrySize);
  if (crc32(entries) !== block.readUInt32LE(88)) throw Error('GPT entry-array CRC mismatch');
  return { currentLBA, otherLBA, entries, count, entrySize, firstUsableLBA: number64(block, 40), lastUsableLBA: number64(block, 48) };
}
async function hashFile(file) {
  const h = crypto.createHash('sha256');
  for await (const chunk of fs.createReadStream(file)) h.update(chunk);
  return h.digest('hex');
}
const wanted = /^(vbmeta(?:_system|_vendor)?_[ab]|abl_[ab]|boot_[ab]|init_boot_[ab]|vendor_boot_[ab]|dtbo_[ab]|recovery_[ab]|xbl_[ab]|xbl_config_[ab]|smraw|misc|devinfo|persist)$/;
const partitions = [];
const luns = [];
const partitionDirectory = path.join(backup, 'partitions');
fs.mkdirSync(partitionDirectory, { recursive: true });
for (const { lun, size } of expected) {
  const file = path.join(backup, 'raw', `ufs.bin.lun${lun}`);
  const actualSize = fs.statSync(file).size;
  if (actualSize !== size) throw Error(`LUN ${lun}: expected ${size} bytes, got ${actualSize}`);
  const fd = fs.openSync(file, 'r');
  try {
    const primary = readGPT(fd, 1);
    if ((primary.otherLBA + 1) * sectorSize !== actualSize) throw Error(`LUN ${lun}: GPT does not cover the complete file`);
    const secondary = readGPT(fd, primary.otherLBA);
    if (secondary.otherLBA !== 1 || !secondary.entries.equals(primary.entries) || secondary.firstUsableLBA !== primary.firstUsableLBA || secondary.lastUsableLBA !== primary.lastUsableLBA) throw Error(`LUN ${lun}: primary/secondary GPT disagreement`);
    const ranges = [];
    for (let i = 0; i < primary.count; i++) {
      const entry = primary.entries.subarray(i * primary.entrySize, (i + 1) * primary.entrySize);
      if (entry.subarray(0, 16).every(v => v === 0)) continue;
      const name = entry.toString('utf16le', 56, Math.min(128, primary.entrySize)).replace(/\0.*$/s, '');
      const firstLBA = number64(entry, 32);
      const lastLBA = number64(entry, 40);
      const start = firstLBA * sectorSize;
      const length = (lastLBA + 1) * sectorSize - start;
      if (firstLBA > lastLBA || firstLBA < primary.firstUsableLBA || lastLBA > primary.lastUsableLBA || start + length > actualSize) throw Error(`Invalid bounds for ${name}`);
      ranges.push({ firstLBA, lastLBA, name });
      const item = { name, lun, offsetBytes: start, sizeBytes: length, attributes: `0x${entry.readBigUInt64LE(48).toString(16)}` };
      if (wanted.test(name)) {
        const output = path.join(partitionDirectory, name + '.img');
        const exists = fs.existsSync(output);
        const temporary = output + '.partial-' + process.pid;
        const out = exists ? null : fs.openSync(temporary, 'wx', 0o600);
        const h = crypto.createHash('sha256');
        try {
          for (let n = 0; n < length;) {
            const chunk = readExact(fd, start + n, Math.min(4 * 1024 * 1024, length - n));
            if (out !== null) {
              let written = 0;
              while (written < chunk.length) written += fs.writeSync(out, chunk, written, chunk.length - written);
            }
            h.update(chunk);
            n += chunk.length;
          }
        } finally { if (out !== null) fs.closeSync(out); }
        const digest = h.digest('hex');
        if (exists) {
          if (fs.statSync(output).size !== length || await hashFile(output) !== digest) throw Error(`Existing extracted original differs from raw backup: ${name}`);
        } else {
          fs.renameSync(temporary, output);
        }
        item.extractedFile = path.relative(backup, output);
        item.sha256 = digest;
      }
      partitions.push(item);
    }
    ranges.sort((a, b) => a.firstLBA - b.firstLBA);
    for (let i = 1; i < ranges.length; i++) {
      if (ranges[i].firstLBA <= ranges[i - 1].lastLBA) throw Error(`LUN ${lun}: overlapping partitions ${ranges[i - 1].name} and ${ranges[i].name}`);
    }
  } finally { fs.closeSync(fd); }
  console.log(`LUN ${lun}: size and both GPT CRCs verified, hashing ${actualSize} bytes`);
  luns.push({ lun, file: path.relative(backup, file), sizeBytes: actualSize, sha256: await hashFile(file), primaryGPTValid: true, backupGPTValid: true });
}

const rereadNames = ['vbmeta_a', 'vbmeta_b', 'vbmeta_system_a', 'vbmeta_system_b', 'abl_a', 'abl_b', 'smraw'];
const rereads = [];
for (const name of rereadNames) {
  const item = partitions.find(p => p.name === name);
  if (!item?.sha256) throw Error(`Missing extracted ${name}`);
  const file = path.join(backup, 'verification', name + '.img');
  if (!fs.existsSync(file) || fs.statSync(file).size !== item.sizeBytes) throw Error(`Missing or incomplete independent reread: ${name}`);
  const digest = await hashFile(file);
  if (digest !== item.sha256) throw Error(`Independent device reread mismatch: ${name}`);
  rereads.push({ partition: name, sizeBytes: item.sizeBytes, sha256: digest, matchesRawBackup: true });
}

const avbDirectory = path.join(backup, 'analysis/avb');
fs.mkdirSync(avbDirectory, { recursive: true });
const keyNames = ['testkey_rsa2048', 'testkey_rsa2048_2', 'testkey_rsa4096', 'testkey_rsa8192'];
const avbResults = [];
function tool(args) {
  const result = spawnSync(py, [avb, ...args], { encoding: 'utf8', maxBuffer: 20 * 1024 * 1024, env: { ...process.env, PATH: '/opt/homebrew/bin:' + process.env.PATH } });
  if (result.error) throw result.error;
  return { status: result.status, text: (result.stdout || '') + (result.stderr || '') };
}
for (const slot of ['a', 'b']) {
  const slotDirectory = path.join(avbDirectory, 'slot-' + slot);
  fs.mkdirSync(slotDirectory, { recursive: true });
  for (const p of partitions.filter(p => p.extractedFile && p.name.endsWith('_' + slot))) {
    const link = path.join(slotDirectory, p.name.replace(/_[ab]$/, '') + '.img');
    if (!fs.existsSync(link)) fs.symlinkSync(path.join(backup, p.extractedFile), link);
  }
  for (const base of ['vbmeta', 'vbmeta_system', 'vbmeta_vendor']) {
    const partitionName = base + '_' + slot;
    const image = path.join(slotDirectory, base + '.img');
    if (!fs.existsSync(image)) continue;
    const pubFile = path.join(avbDirectory, partitionName + '.avbpubkey');
    const info = tool(['info_image', '--image', image, '--output_pubkey', pubFile]);
    fs.writeFileSync(path.join(avbDirectory, partitionName + '-info.txt'), info.text);
    if (info.status !== 0) throw Error(`avbtool info failed for ${partitionName}`);
    const deviceKey = fs.existsSync(pubFile) ? fs.readFileSync(pubFile) : Buffer.alloc(0);
    const matches = keyNames.filter(name => deviceKey.length && fs.readFileSync(path.join(backup, 'analysis/aosp-public-keys', name + '.avbpubkey')).equals(deviceKey));
    const args = ['verify_image', '--image', image];
    if (matches.length) args.push('--key', path.join(root, 'tools/avb/test/data', matches[0] + '.pem'));
    const chainMatches = [...info.text.matchAll(/Chain Partition descriptor:\s*\n\s*Partition Name:\s*(\S+)\s*\n\s*Rollback Index Location:\s*(\d+)/g)];
    for (const chain of chainMatches) {
      const childImage = path.join(slotDirectory, chain[1] + '.img');
      const childPublicKey = path.join(avbDirectory, chain[1] + '_' + slot + '.avbpubkey');
      if (fs.existsSync(childImage)) {
        const childInfo = tool(['info_image', '--image', childImage, '--output_pubkey', childPublicKey]);
        if (childInfo.status !== 0) throw Error(`Cannot extract chained public key for ${chain[1]}`);
        args.push('--expected_chain_partition', `${chain[1]}:${chain[2]}:${childPublicKey}`);
      }
    }
    const verification = tool(args);
    fs.writeFileSync(path.join(avbDirectory, partitionName + '-verify.txt'), verification.text);
    const signatureLine = verification.text.split('\n').find(line => line.startsWith('vbmeta: Successfully verified ') && line.endsWith(' in ' + image));
    const result = {
      partition: partitionName,
      algorithm: info.text.match(/^Algorithm:\s*(.+)$/m)?.[1]?.trim() || null,
      publicKeySHA1: info.text.match(/^Public key \(sha1\):\s*(.+)$/m)?.[1]?.trim() || null,
      declaredRollbackIndex: info.text.match(/^Rollback Index:\s*(.+)$/m)?.[1]?.trim() || null,
      aospKeyMatches: matches,
      embeddedVBMetaSignatureValid: Boolean(signatureLine) && deviceKey.length > 0 && !/^Algorithm:\s*NONE\s*$/m.test(info.text),
      aospSignedVBMetaConfirmed: matches.length > 0 && Boolean(signatureLine) && deviceKey.length > 0,
      localDescriptorVerificationSucceeded: verification.status === 0,
      completeDescriptorVerificationSucceeded: verification.status === 0 && chainMatches.length === 0,
      chainedPartitionsCheckedAgainstExtractedChildKey: chainMatches.map(c => c[1]),
      verificationExitCode: verification.status,
      details: path.relative(backup, path.join(avbDirectory, partitionName + '-verify.txt'))
    };
    avbResults.push(result);
    console.log(JSON.stringify(result));
  }
}
for (const result of avbResults) {
  if (result.chainedPartitionsCheckedAgainstExtractedChildKey.length) {
    const slot = result.partition.slice(-1);
    result.completeDescriptorVerificationSucceeded = result.localDescriptorVerificationSucceeded && result.chainedPartitionsCheckedAgainstExtractedChildKey.every(name => avbResults.find(child => child.partition === name + '_' + slot)?.completeDescriptorVerificationSucceeded === true);
  }
}
const manifest = {
  createdAt: new Date().toISOString(), sectorSizeBytes: sectorSize,
  scope: 'All six GPT-addressed UFS LUNs including userdata and primary/backup GPTs; excludes RPMB, fuses, and non-addressable secure state.',
  deviceWritesPerformed: false, totalRawBytes: luns.reduce((n, l) => n + l.sizeBytes, 0),
  luns, partitions, independentDeviceRereads: rereads, avb: avbResults,
  limitations: ['No restore was attempted.', 'A key embedded in a signed image is not independent proof of the bootloader trust policy.', 'Descriptor verification can be incomplete because logical images inside super have not been unpacked.', 'Stored hardware rollback counters were not read.']
};
fs.writeFileSync(path.join(backup, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
fs.writeFileSync(path.join(backup, 'SHA256SUMS'), luns.map(l => `${l.sha256}  ${l.file}`).join('\n') + '\n');
fs.writeFileSync(path.join(backup, 'analysis/avb-results.json'), JSON.stringify(avbResults, null, 2) + '\n');
for (const l of luns) fs.chmodSync(path.join(backup, l.file), 0o400);
for (const p of partitions.filter(p => p.extractedFile)) fs.chmodSync(path.join(backup, p.extractedFile), 0o400);
fs.writeFileSync(path.join(backup, 'logs/verification-complete.json'), JSON.stringify({ completedAt: new Date().toISOString(), totalRawBytes: manifest.totalRawBytes, luns: luns.length, independentRereads: rereads.length, avb: avbResults }, null, 2) + '\n');
console.log(`BACKUP_VERIFIED: ${luns.length} LUNs, ${manifest.totalRawBytes} raw bytes, ${rereads.length} independent rereads`);
