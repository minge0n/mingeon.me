import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

process.umask(0o077);
const backup = '/path/to/toss-front2/backups/20261102-193800-stock';
const manifest = JSON.parse(fs.readFileSync(path.join(backup, 'manifest.json'), 'utf8'));
const superPartition = manifest.partitions.find(p => p.name === 'super');
if (!superPartition) throw Error('No super partition');
const source = path.join(backup, 'raw', 'ufs.bin.lun' + superPartition.lun);
const fd = fs.openSync(source, 'r');
const out = path.join(backup, 'analysis/super');
fs.mkdirSync(out, { recursive: true });
const sha = b => crypto.createHash('sha256').update(b).digest();
const u64 = (b, o) => {
  const n = Number(b.readBigUInt64LE(o));
  if (!Number.isSafeInteger(n)) throw Error('Unsafe 64-bit value');
  return n;
};
function read(offset, size) {
  if (offset < 0 || size < 0 || offset + size > superPartition.sizeBytes) throw Error('Read outside super');
  const b = Buffer.alloc(size);
  let n = 0;
  while (n < size) {
    const got = fs.readSync(fd, b, n, size - n, superPartition.offsetBytes + offset + n);
    if (!got) throw Error('Short raw read');
    n += got;
  }
  return b;
}
function geometry(offset) {
  const b = read(offset, 4096);
  if (b.readUInt32LE(0) !== 0x616c4467) throw Error('Invalid LP geometry magic');
  const size = b.readUInt32LE(4);
  if (size < 52 || size > 4096) throw Error('Invalid LP geometry size');
  const c = Buffer.from(b.subarray(0, size));
  c.fill(0, 8, 40);
  if (!sha(c).equals(b.subarray(8, 40))) throw Error('LP geometry checksum mismatch');
  return { bytes: b.subarray(0, size), metadataMaxSize: b.readUInt32LE(40), slots: b.readUInt32LE(44), logicalBlockSize: b.readUInt32LE(48) };
}
const g = geometry(4096), gb = geometry(8192);
if (!g.bytes.equals(gb.bytes)) throw Error('Primary/backup LP geometry differs');
if (!g.slots || g.slots > 8 || g.metadataMaxSize > 16 * 1024 * 1024 || !g.metadataMaxSize) throw Error('Invalid LP geometry limits');
function metadata(offset, slot, copy) {
  const b = read(offset, g.metadataMaxSize);
  if (b.readUInt32LE(0) !== 0x414c5030) return { slot, copy, valid: false, reason: 'No LP metadata magic' };
  const major = b.readUInt16LE(4), minor = b.readUInt16LE(6), headerSize = b.readUInt32LE(8), tableSize = b.readUInt32LE(44);
  if (major !== 10 || minor > 2 || headerSize < 128 || headerSize > 256 || headerSize + tableSize > b.length) throw Error('Unsupported or invalid LP metadata header');
  const header = Buffer.from(b.subarray(0, headerSize));
  header.fill(0, 12, 44);
  if (!sha(header).equals(b.subarray(12, 44))) throw Error(`LP header checksum mismatch ${slot}/${copy}`);
  const tables = b.subarray(headerSize, headerSize + tableSize);
  if (!sha(tables).equals(b.subarray(48, 80))) throw Error(`LP tables checksum mismatch ${slot}/${copy}`);
  function table(descriptorOffset, minEntrySize) {
    const start = b.readUInt32LE(descriptorOffset), count = b.readUInt32LE(descriptorOffset + 4), size = b.readUInt32LE(descriptorOffset + 8);
    if (count > 8192 || size < minEntrySize || start + count * size > tables.length) throw Error('Invalid LP table bounds');
    return Array.from({ length: count }, (_, i) => tables.subarray(start + i * size, start + (i + 1) * size));
  }
  const blocks = table(116, 64).map(e => ({ name: e.toString('ascii', 24, 60).replace(/\0.*$/s, ''), firstLogicalSector: u64(e, 0), alignmentBytes: e.readUInt32LE(8), alignmentOffsetBytes: e.readUInt32LE(12), sizeBytes: u64(e, 16), flags: e.readUInt32LE(60) }));
  const extents = table(92, 24).map(e => ({ sectors: u64(e, 0), type: e.readUInt32LE(8), targetSector: u64(e, 12), blockDevice: e.readUInt32LE(20) }));
  for (const e of extents) {
    if (e.type !== 0 && e.type !== 1) throw Error('Unknown LP extent type');
    if (e.type === 0 && (!blocks[e.blockDevice] || e.targetSector < blocks[e.blockDevice].firstLogicalSector || (e.targetSector + e.sectors) * 512 > blocks[e.blockDevice].sizeBytes)) throw Error('Extent outside physical device');
    if (e.type === 1 && (e.targetSector !== 0 || e.blockDevice !== 0)) throw Error('Invalid zero extent');
  }
  const groups = table(104, 48).map(e => ({ name: e.toString('ascii', 0, 36).replace(/\0.*$/s, ''), flags: e.readUInt32LE(36), maximumSizeBytes: u64(e, 40), allocatedBytes: 0 }));
  const partitions = table(80, 52).map(e => {
    const name = e.toString('ascii', 0, 36).replace(/\0.*$/s, '');
    const first = e.readUInt32LE(40), count = e.readUInt32LE(44), groupIndex = e.readUInt32LE(48);
    if (!/^[A-Za-z0-9_-]+$/.test(name) || first + count > extents.length || !groups[groupIndex]) throw Error(`Invalid logical partition ${JSON.stringify({name,first,count,groupIndex,extentCount:extents.length,groupCount:groups.length})}`);
    const owned = extents.slice(first, first + count);
    const sizeBytes = owned.reduce((n, x) => n + x.sectors * 512, 0);
    groups[groupIndex].allocatedBytes += sizeBytes;
    return { name, attributes: e.readUInt32LE(36), group: groups[groupIndex].name, sizeBytes, extents: owned };
  });
  for (const group of groups) if (group.maximumSizeBytes && group.allocatedBytes > group.maximumSizeBytes) throw Error('LP group exceeds maximum');
  const physical = blocks.map((device, index) => {
    const ranges = partitions.flatMap(p => p.extents).filter(e => e.type === 0 && e.blockDevice === index).map(e => [e.targetSector * 512, (e.targetSector + e.sectors) * 512]).sort((a, c) => a[0] - c[0]);
    let allocatedBytes = 0, end = 0;
    for (const [start, stop] of ranges) { allocatedBytes += Math.max(0, stop - Math.max(start, end)); end = Math.max(end, stop); }
    return { ...device, allocatedPhysicalBytes: allocatedBytes, unallocatedDataBytes: device.sizeBytes - device.firstLogicalSector * 512 - allocatedBytes };
  });
  return { slot, copy, valid: true, version: `${major}.${minor}`, headerFlags: headerSize >= 132 ? b.readUInt32LE(128) : 0, metadataSHA256: sha(b.subarray(0, headerSize + tableSize)).toString('hex'), groups, physicalDevices: physical, partitions };
}
const copies = [];
try {
  for (let slot = 0; slot < g.slots; slot++) {
    const primary = metadata(12288 + slot * g.metadataMaxSize, slot, 'primary');
    const secondary = metadata(12288 + g.slots * g.metadataMaxSize + slot * g.metadataMaxSize, slot, 'backup');
    if (primary.valid && secondary.valid && primary.metadataSHA256 !== secondary.metadataSHA256) throw Error(`Primary/backup LP metadata differs for slot ${slot}`);
    copies.push(primary, secondary);
  }
  const report = { sourceRaw: source, superOffsetBytes: superPartition.offsetBytes, superSizeBytes: superPartition.sizeBytes, sourceSpecification: 'https://android.googlesource.com/platform/system/core/+/master/fs_mgr/liblp/include/liblp/metadata_format.h', geometry: { metadataMaxSize: g.metadataMaxSize, metadataSlotCount: g.slots, logicalBlockSize: g.logicalBlockSize, primaryBackupMatch: true }, copies };
  fs.writeFileSync(path.join(out, 'layout.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ ...report, copies: copies.map(c => c.valid ? { ...c, partitions: c.partitions.map(p => ({ name: p.name, sizeMiB: p.sizeBytes / 1048576, group: p.group, extents: p.extents.length })) } : c) }, null, 2));
} finally { fs.closeSync(fd); }
