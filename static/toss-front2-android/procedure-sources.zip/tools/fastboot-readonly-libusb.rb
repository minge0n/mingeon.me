require 'fiddle'
require 'json'

TARGET_SERIAL = 'TARGET_SERIAL'.freeze
QUERIES = %w[is-userspace current-slot unlocked secure snapshot-update-status slot-successful:a slot-successful:b].freeze

def parse_config(bytes)
  raise 'Invalid USB configuration header' unless bytes.bytesize >= 9 && bytes.getbyte(1) == 2
  total = bytes.byteslice(2, 2).unpack1('v')
  raise 'Truncated USB configuration' unless total <= bytes.bytesize
  matches = []
  current = nil
  pos = 0
  while pos < total
    len = bytes.getbyte(pos)
    kind = bytes.getbyte(pos + 1)
    raise 'Malformed USB descriptor length' unless len && len >= 2 && pos + len <= total
    if kind == 4
      raise 'Truncated interface descriptor' unless len >= 9
      current = nil
      if bytes.getbyte(pos + 3) == 0 && bytes.byteslice(pos + 5, 3).bytes == [255, 66, 3]
        current = { interface: bytes.getbyte(pos + 2), endpoints: [] }
        matches << current
      end
    elsif kind == 5 && current
      raise 'Truncated endpoint descriptor' unless len >= 7
      if (bytes.getbyte(pos + 3) & 3) == 2
        current[:endpoints] << bytes.getbyte(pos + 2)
      end
    end
    pos += len
  end
  raise 'Expected one fastboot USB interface' unless matches.length == 1
  found = matches.first
  ins = found[:endpoints].select { |v| (v & 128) != 0 }
  outs = found[:endpoints].select { |v| (v & 128) == 0 }
  raise 'Expected one input and one output endpoint' unless ins.length == 1 && outs.length == 1
  { interface: found[:interface], input: ins.first, output: outs.first }
end

if ARGV == ['--self-test']
  raw = [9,2,32,0,1,1,0,128,250,9,4,0,0,2,255,66,3,0,7,5,129,2,0,2,0,7,5,1,2,0,2,0].pack('C*')
  raise 'Descriptor parser failure' unless parse_config(raw) == { interface: 0, input: 129, output: 1 }
  begin
    parse_config(raw.byteslice(0, 19))
    raise 'Truncation guard failed'
  rescue RuntimeError => e
    raise if e.message == 'Truncation guard failed'
  end
  puts JSON.pretty_generate(self_test: 'passed', command_allowlist: QUERIES, storage_writes_supported: false)
  exit 0
end
raise 'Usage: ruby tool.rb --probe | --query' unless [['--probe'], ['--query']].include?(ARGV)

lib = Fiddle.dlopen('/opt/homebrew/lib/libusb-1.0.dylib')
vp = Fiddle::TYPE_VOIDP
int = Fiddle::TYPE_INT
lng = Fiddle::TYPE_LONG
fn = lambda { |name, args, result| Fiddle::Function.new(lib[name], args, result) }
init = fn.call('libusb_init', [vp], int)
exit_usb = fn.call('libusb_exit', [vp], Fiddle::TYPE_VOID)
open_dev = fn.call('libusb_open_device_with_vid_pid', [vp, int, int], vp)
get_dev = fn.call('libusb_get_device', [vp], vp)
get_desc = fn.call('libusb_get_device_descriptor', [vp, vp], int)
get_str = fn.call('libusb_get_string_descriptor_ascii', [vp, int, vp, int], int)
get_conf = fn.call('libusb_get_configuration', [vp, vp], int)
control = fn.call('libusb_control_transfer', [vp, int, int, int, int, vp, int, int], int)
claim = fn.call('libusb_claim_interface', [vp, int], int)
release = fn.call('libusb_release_interface', [vp, int], int)
bulk = fn.call('libusb_bulk_transfer', [vp, int, vp, int, vp, int], int)
close = fn.call('libusb_close', [vp], Fiddle::TYPE_VOID)
error_name = fn.call('libusb_error_name', [int], vp)
check = lambda do |result, stage|
  if result < 0
    ep = error_name.call(result)
    raise "#{stage}: #{Fiddle::Pointer.new(ep.to_i).to_s} (#{result})"
  end
  result
end
ctxbuf = Fiddle::Pointer.malloc(Fiddle::SIZEOF_VOIDP)
ctxbuf[0, Fiddle::SIZEOF_VOIDP] = "\0" * Fiddle::SIZEOF_VOIDP
check.call(init.call(ctxbuf), 'libusb_init')
ctx = ctxbuf[0, Fiddle::SIZEOF_VOIDP].unpack1('Q')
handle = nil
claimed = nil
begin
  handle = open_dev.call(ctx, 0x18d1, 0x4ee0)
  if handle.to_i == 0
    puts JSON.pretty_generate(state: 'target_usb_not_present', vid: '0x18d1', pid: '0x4ee0', storage_writes: false)
    exit 2
  end
  desc = Fiddle::Pointer.malloc(18)
  check.call(get_desc.call(get_dev.call(handle), desc), 'device_descriptor')
  db = desc.to_s(18)
  serial_buf = Fiddle::Pointer.malloc(256)
  sn = check.call(get_str.call(handle, db.getbyte(16), serial_buf, 256), 'serial_descriptor')
  serial = serial_buf.to_s(sn)
  raise "Refusing a different USB serial: #{serial}" unless serial == TARGET_SERIAL
  cfg = Fiddle::Pointer.malloc(4)
  check.call(get_conf.call(handle, cfg), 'active_configuration')
  config = cfg.to_s(4).unpack1('i')
  raise 'No active configuration; refusing to set or reset USB configuration' unless config > 0
  confbuf = Fiddle::Pointer.malloc(4096)
  got = check.call(control.call(handle, 128, 6, 0x0200, 0, confbuf, 4096, 3000), 'configuration_descriptor')
  endpoints = parse_config(confbuf.to_s(got))
  info = { state: 'target_descriptor_verified', serial: serial, active_configuration: config, endpoints: endpoints, usb_configuration_changed: false, storage_writes: false }
  if ARGV == ['--probe']
    puts JSON.pretty_generate(info)
    exit 0
  end
  check.call(claim.call(handle, endpoints[:interface]), 'claim_fastboot_interface')
  claimed = endpoints[:interface]
  responses = {}
  QUERIES.each do |key|
    packet = "getvar:#{key}"
    actual = Fiddle::Pointer.malloc(4)
    check.call(bulk.call(handle, endpoints[:output], Fiddle::Pointer[packet], packet.bytesize, actual, 5000), "send #{key}")
    raise 'Partial fastboot command transfer' unless actual.to_s(4).unpack1('i') == packet.bytesize
    completed = false
    32.times do
      response = Fiddle::Pointer.malloc(64)
      check.call(bulk.call(handle, endpoints[:input], response, 64, actual, 5000), "receive #{key}")
      count = actual.to_s(4).unpack1('i')
      raise 'Short fastboot reply' unless count >= 4
      text = response.to_s(count)
      tag, body = text.byteslice(0, 4), text.byteslice(4, count - 4)
      next if tag == 'INFO'
      raise "Unexpected fastboot reply type #{tag.inspect}" unless ['OKAY', 'FAIL'].include?(tag)
      responses[key] = { status: tag, value: body }
      completed = true
      puts JSON.generate(query: key, response: responses[key])
      STDOUT.flush
      break
    end
    raise 'Fastboot reply limit exceeded' unless completed
  end
  puts JSON.pretty_generate(info.merge(state: 'readonly_queries_complete', responses: responses))
ensure
  release.call(handle, claimed) if handle && handle.to_i != 0 && !claimed.nil?
  close.call(handle) if handle && handle.to_i != 0
  exit_usb.call(ctx)
end
