#!/bin/bash
set -euo pipefail
umask 077
ROOT=/path/to/toss-front2
B="$ROOT/backups/20261102-193800-stock"
NODE=/path/to/node
if [ -f "$B/logs/verification-complete.json" ]; then
  cat "$B/logs/verification-complete.json"
  exit 0
fi
if [ ! -f "$B/logs/full-read.exit-code" ]; then
  printf '%s\n' 'Raw device read is still running; no second USB operation was started.'
  exit 75
fi
if [ "$(cat "$B/logs/full-read.exit-code")" != 0 ]; then
  printf '%s\n' 'Raw backup read failed. Stop and inspect full-read.log; do not flash or retry writes.'
  exit 1
fi
if ! mkdir "$B/logs/verification.lock" 2>/dev/null; then
  printf '%s\n' 'A verification process already holds the lock.'
  exit 75
fi
trap 'rmdir "$B/logs/verification.lock"' EXIT
cd "$ROOT"
mkdir -p "$B/verification"
if [ ! -f "$B/logs/reread.exit-code" ]; then
  PARTS=vbmeta_a,vbmeta_b,vbmeta_system_a,vbmeta_system_b,abl_a,abl_b,smraw
  FILES="$B/verification/vbmeta_a.img,$B/verification/vbmeta_b.img,$B/verification/vbmeta_system_a.img,$B/verification/vbmeta_system_b.img,$B/verification/abl_a.img,$B/verification/abl_b.img,$B/verification/smraw.img"
  set +e
  ./edl/.venv312/bin/edl r "$PARTS" "$FILES" --memory=ufs --loader="$ROOT/firehose.elf" > "$B/logs/independent-reread.log" 2>&1
  RC=$?
  set -e
  printf '%s\n' "$RC" > "$B/logs/reread.exit-code"
  if [ "$RC" != 0 ]; then
    printf '%s\n' 'Independent read failed; original raw dumps remain untouched.'
    exit "$RC"
  fi
fi
if [ "$(cat "$B/logs/reread.exit-code")" != 0 ]; then
  printf '%s\n' 'An earlier independent read failed; inspect its log before continuing.'
  exit 1
fi
"$NODE" "$ROOT/tools/verify-stock-backup.mjs" "$B" 2>&1 | tee "$B/logs/verification.log"
