# HISTORICAL RECORD ONLY. DO NOT EXECUTE AS A GENERIC INSTALLER.
# 승인된 metadata 초기화용 빈 ext4 이미지 준비·읽기 검증
set -e
cd /path/to/toss-front2
D="$PWD/images/prepared-gsi"; export PREP_DIR="$D"
node --input-type=module <<'JS'
import fs from 'node:fs';const p=process.env.PREP_DIR+'/metadata-clean.img',fd=fs.openSync(p,'wx',0o600);fs.ftruncateSync(fd,67108864);fs.closeSync(fd);console.log({localImage:p,bytes:67108864,deviceTouched:false});
JS
MKE2FS_CONFIG=/path/to/Android/sdk/platform-tools/mke2fs.conf /path/to/Android/sdk/platform-tools/mke2fs -q -F -t ext4 -b 4096 -I 512 -m 0 -E lazy_itable_init=0,lazy_journal_init=0 "$D/metadata-clean.img" 16384 > analysis/install-plan/metadata-format.log 2>&1
cat analysis/install-plan/metadata-format.log
node analysis/init-offline/ext4_read.mjs list "$D/metadata-clean.img" / > analysis/install-plan/metadata-clean-root.json
cat analysis/install-plan/metadata-clean-root.json
node --input-type=module <<'JS'
import fs from 'node:fs';import crypto from 'node:crypto';const d=process.env.PREP_DIR,p=d+'/metadata-clean.img',b=fs.readFileSync(p),s=b.subarray(1024,2048),listing=JSON.parse(fs.readFileSync('analysis/install-plan/metadata-clean-root.json'));if(s.readUInt16LE(56)!==0xef53||s.readUInt32LE(92)!==0x2c||s.readUInt32LE(96)!==0x42||s.readUInt32LE(100)!==0x7b||s.readUInt16LE(88)!==512)throw Error('Unexpected metadata filesystem profile');if(listing.entries.some(e=>!['.','..','lost+found'].includes(e.name)))throw Error('Unexpected files in clean metadata');const r={preparedAt:new Date().toISOString(),file:p,bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),blockSize:4096,inodeSize:512,features:{compat:'0x2c',incompat:'0x42',roCompat:'0x7b'},noOldSnapshotOrEncryptionState:true,deviceWritesThisStep:false,purpose:'Clear approved metadata before booting recovery so old OTA state cannot remap the newly rebuilt super. Stock recovery then formats userdata/metadata via --wipe_data.'};fs.writeFileSync(d+'/metadata-ready.json',JSON.stringify(r,null,2));console.log(r);
JS
