# HISTORICAL RECORD ONLY. DO NOT EXECUTE AS A GENERIC INSTALLER.
# 6개 UFS LUN 전체 백업 시작
cd /path/to/toss-front2 || exit 1
umask 077
BACKUP="$PWD/backups/$(date +%Y%m%d-%H%M%S)-stock"
mkdir -p "$BACKUP/raw" "$BACKUP/partitions" "$BACKUP/logs" "$BACKUP/analysis" || exit 1
printf '%s\n' "$BACKUP" > logs/active-backup-path.txt
cp logs/gpt-20261102-193626.txt "$BACKUP/logs/initial-gpt.txt" || exit 1
printf 'BACKUP=%s\n' "$BACKUP"
printf 'STARTED=%s\n' "$(date -Iseconds)"
./edl/.venv312/bin/edl rf "$BACKUP/raw/ufs.bin" --memory=ufs --loader="$PWD/firehose.elf" > "$BACKUP/logs/full-read.log" 2>&1
RC=$?
printf '%s\n' "$RC" > "$BACKUP/logs/full-read.exit-code"
printf 'EDL_EXIT=%s\n' "$RC"
tail -n 25 "$BACKUP/logs/full-read.log"
exit "$RC"
