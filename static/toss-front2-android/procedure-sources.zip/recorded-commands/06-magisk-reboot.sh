# HISTORICAL RECORD ONLY. DO NOT EXECUTE AS A GENERIC INSTALLER.
# 검증된 Magisk 설치로 재부팅
cd /path/to/toss-front2 && node --input-type=module <<'JS'
import fs from'node:fs';import{spawnSync}from'node:child_process';const f='analysis/magisk-install/applied-pair.json',s=JSON.parse(fs.readFileSync(f));if(s.state!=='VERIFIED_PENDING_REBOOT'||s.rebootIssued)throw Error('Reboot gate missing');s.rebootRequestedAt=new Date().toISOString();fs.writeFileSync(f,JSON.stringify(s,null,2));const r=spawnSync('/path/to/Android/sdk/platform-tools/adb',['-s','TARGET_ADB_ENDPOINT','reboot'],{encoding:'utf8',timeout:15000});s.rebootCommandExit=r.status;s.rebootIssued=r.status===0;s.rebootCommandError=r.stderr?.trim()||null;fs.writeFileSync(f,JSON.stringify(s,null,2));console.log({rebootIssued:s.rebootIssued,rebootRequestedAt:s.rebootRequestedAt,error:s.rebootCommandError});
JS
