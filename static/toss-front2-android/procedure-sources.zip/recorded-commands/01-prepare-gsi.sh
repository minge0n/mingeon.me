# HISTORICAL RECORD ONLY. DO NOT EXECUTE AS A GENERIC INSTALLER.
# 기존 키와 롤백 인덱스를 유지한 GSI·vbmeta_system 제작
set -e
cd /path/to/toss-front2
D="$PWD/images/prepared-gsi"; mkdir -p "$D"; export PREP_DIR="$D"
AVB="$PWD/tools/avb/avbtool.py"; KEY="$PWD/tools/avb/test/data/testkey_rsa2048.pem"
"$AVB" make_vbmeta_image --output "$D/system-footer.vbmeta" --algorithm SHA256_RSA2048 --key "$KEY" --rollback_index 0 --rollback_index_location 0 --include_descriptors_from_image images/lineage-22.2-20251015-UNOFFICIAL-gsi_arm64_gN.img
node --input-type=module <<'JS'
import fs from 'node:fs';import crypto from 'node:crypto';const d=process.env.PREP_DIR,src='images/lineage-22.2-20251015-UNOFFICIAL-gsi_arm64_gN.img',dest=d+'/system_b.img',size=fs.statSync(src).size;const tail=Buffer.alloc(64),fd=fs.openSync(src,'r');fs.readSync(fd,tail,0,64,size-64);fs.closeSync(fd);if(tail.subarray(0,4).toString()!=='AVBf')throw Error('Source footer magic');const off=Number(tail.readBigUInt64BE(20)),oldSize=Number(tail.readBigUInt64BE(28)),meta=fs.readFileSync(d+'/system-footer.vbmeta');if(off+meta.length>size-64||meta.length>oldSize)throw Error('New vbmeta does not fit existing footer area');fs.copyFileSync(src,dest,fs.constants.COPYFILE_EXCL|fs.constants.COPYFILE_FICLONE);const out=fs.openSync(dest,'r+');fs.writeSync(out,Buffer.alloc(oldSize),0,oldSize,off);fs.writeSync(out,meta,0,meta.length,off);tail.writeBigUInt64BE(BigInt(meta.length),28);fs.writeSync(out,tail,0,64,size-64);fs.fsyncSync(out);fs.closeSync(out);console.log({candidate:dest,bytes:size,filesystemAndTreeUnchanged:true,vbmetaOffset:off,oldVbmetaSize:oldSize,newVbmetaSize:meta.length,systemFooterRollbackIndex:0});
JS
"$AVB" make_vbmeta_image --output "$D/vbmeta_system_b.img" --padding_size 65536 --algorithm SHA256_RSA2048 --key "$KEY" --rollback_index 1709251200 --rollback_index_location 0 --include_descriptors_from_image "$D/system_b.img" --include_descriptors_from_image backups/20261102-193800-stock/analysis/logical-slot-b/product_b.img
"$AVB" extract_public_key --key "$KEY" --output "$D/prepared-system.avbpubkey"
cmp "$D/prepared-system.avbpubkey" backups/20261102-193800-stock/analysis/avb/vbmeta_system_b.avbpubkey
V="$PWD/backups/20261102-193800-stock/analysis/prepared-chain"; mkdir -p "$V"
export CHAIN_DIR="$V"
node --input-type=module <<'JS'
import fs from 'node:fs';import path from 'node:path';const d=process.env.CHAIN_DIR,prep=process.env.PREP_DIR,root=path.resolve('backups/20261102-193800-stock');for(const [alias,name]of Object.entries({vbmeta:'vbmeta_b',boot:'boot_b',init_boot:'init_boot_b',vendor_boot:'vendor_boot_b',dtbo:'dtbo_b',recovery:'recovery_b'})){const target=path.join(root,'partitions',name+'.img'),dest=path.join(d,alias+'.img');if(!fs.existsSync(dest))fs.symlinkSync(path.relative(d,target),dest);}for(const n of ['odm','product','system_dlkm','vendor','vendor_dlkm']){const dest=path.join(d,n+'.img'),target=path.join(root,'analysis/logical-slot-b',n+'_b.img');if(!fs.existsSync(dest))fs.symlinkSync(path.relative(d,target),dest);}for(const[n,target]of Object.entries({system:path.join(prep,'system_b.img'),vbmeta_system:path.join(prep,'vbmeta_system_b.img')})){const dest=path.join(d,n+'.img');if(!fs.existsSync(dest))fs.symlinkSync(path.relative(d,target),dest);}
JS
"$AVB" verify_image --image "$V/vbmeta.img" --expected_chain_partition vbmeta_system:2:backups/20261102-193800-stock/analysis/avb/vbmeta_system_b.avbpubkey --follow_chain_partitions > "$D/verify-prepared-chain.txt" 2>&1
cat "$D/verify-prepared-chain.txt"
"$AVB" verify_image --image "$V/system.img" --key "$KEY" > "$D/verify-prepared-system.txt" 2>&1
cat "$D/verify-prepared-system.txt"
node --input-type=module <<'JS'
import fs from 'node:fs';import crypto from 'node:crypto';const d=process.env.PREP_DIR,shaFile=p=>{const h=crypto.createHash('sha256'),fd=fs.openSync(p,'r'),buf=Buffer.alloc(8*1024*1024);let n;try{while((n=fs.readSync(fd,buf,0,buf.length,null))>0)h.update(buf.subarray(0,n));}finally{fs.closeSync(fd)}return h.digest('hex')};const report={preparedAt:new Date().toISOString(),source:'lineage-22.2-20251015-UNOFFICIAL-gsi_arm64_gN.img',sourceSHA256:'a81a4eb637df101722ddd3793ff3fd1322f4ac0de4b1b10326eecf8db6f4ff42',systemImage:{file:d+'/system_b.img',bytes:fs.statSync(d+'/system_b.img').size,sha256:shaFile(d+'/system_b.img'),embeddedRollbackIndex:0},vbmetaSystem:{file:d+'/vbmeta_system_b.img',bytes:fs.statSync(d+'/vbmeta_system_b.img').size,sha256:shaFile(d+'/vbmeta_system_b.img'),rollbackIndex:1709251200,publicKeyUnchanged:true},topLevelVbmetaUnchanged:true,fullPreparedAVBChainVerified:true,deviceWritesInPreparation:false};fs.writeFileSync(d+'/system-ready.json',JSON.stringify(report,null,2));console.log(report);
JS
