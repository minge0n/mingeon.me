#!/usr/bin/env node
/* Read-only, bounded ext4 path reader. No mount, no writes to input image. */
import fs from 'node:fs/promises';
import crypto from 'node:crypto';

const MAX_BLOCK = 65536, MAX_READ = 1024 * 1024, MAX_FILE = 64 * 1024 * 1024, MAX_EXTENT_DEPTH = 8;
const EXT4_EXTENTS_FL = 0x00080000;
const EXT4_FEATURE_INCOMPAT_FILETYPE=0x2, EXT4_FEATURE_INCOMPAT_EXTENTS=0x40, EXT4_FEATURE_INCOMPAT_64BIT=0x80, EXT4_FEATURE_INCOMPAT_FLEX_BG=0x200;
const UNSUPPORTED_INCOMPAT = 0x1|0x10|0x100|0x400|0x1000|0x8000|0x10000|0x20000; // compression, meta_bg, MMP, EA inode, dirdata, inline, encrypt, casefold
const typeName = m => ({0x4000:'directory',0x8000:'regular',0xa000:'symlink'}[m&0xf000] ?? 'other');
const u16=(b,o)=>b.readUInt16LE(o), u32=(b,o)=>b.readUInt32LE(o);
const u64=(b,o)=>Number(b.readBigUInt64LE(o));
function fail(s){throw new Error(s)}
function json(x){console.log(JSON.stringify(x,null,2))}

class Ext4 {
  constructor(fh,size,sb){this.fh=fh;this.size=size;this.sb=sb}
  static async open(image) {
    const fh=await fs.open(image,'r'); const st=await fh.stat();
    if (!st.isFile()) fail('input is not a regular file');
    const sb=await Ext4.pread(fh,st.size,1024,1024);
    if(u16(sb,56)!==0xef53) fail('not ext4: superblock magic is not 0xef53');
    const log=u32(sb,24), bs=1024*(2**log); if(!Number.isSafeInteger(bs)||bs<1024||bs>MAX_BLOCK) fail(`unsupported block size ${bs}`);
    const inodeSize=u16(sb,88); if(inodeSize<128||inodeSize>bs||inodeSize%4) fail(`invalid inode size ${inodeSize}`);
    const incompat=u32(sb,96), ro=u32(sb,100), compat=u32(sb,92); if(incompat&UNSUPPORTED_INCOMPAT) fail(`unsupported incompatible feature bits 0x${(incompat&UNSUPPORTED_INCOMPAT).toString(16)}`);
    if(!(incompat&EXT4_FEATURE_INCOMPAT_FILETYPE)) fail('unsupported ext directory entries without FILETYPE feature');
    if(!(incompat&EXT4_FEATURE_INCOMPAT_EXTENTS)) fail('unsupported ext4 image without extents');
    const is64=Boolean(incompat&EXT4_FEATURE_INCOMPAT_64BIT), descSize=is64?u16(sb,254):32; if(descSize<32||descSize>bs) fail(`invalid group descriptor size ${descSize}`);
    const blocks= u32(sb,4)+(is64?u32(sb,336)*2**32:0), first=u32(sb,20), bpg=u32(sb,32), ipg=u32(sb,40), inodes=u32(sb,0);
    if(!blocks||!bpg||!ipg||!inodes||blocks>Math.floor(st.size/bs)) fail('invalid superblock block/inode counts');
    const groups=Math.ceil((blocks-first)/bpg), gdtBlock=first+1, gdtBytes=groups*descSize;
    if(gdtBytes>MAX_READ) fail(`group descriptor table ${gdtBytes} exceeds bounded read limit`);
    const gdt=await Ext4.pread(fh,st.size,gdtBlock*bs,gdtBytes);
    const obj=new Ext4(fh,st.size,{bs,inodeSize,incompat,ro,compat,is64,descSize,blocks,first,bpg,ipg,inodes,groups,gdtBlock,gdt,uuid:sb.subarray(104,120).toString('hex')});
    // Validate every group descriptor's inode-table range before any path traversal.
    for(let g=0;g<groups;g++){const d=g*descSize;let tbl=u32(gdt,d+8)+(is64?u32(gdt,d+40)*2**32:0);let count=Math.min(ipg,inodes-g*ipg);let tableBlocks=Math.ceil(count*inodeSize/bs); if(!tbl||tbl+tableBlocks>blocks)fail(`group ${g}: invalid inode table range`)}
    return obj;
  }
  static async pread(fh,size,pos,len){if(!Number.isSafeInteger(pos)||!Number.isSafeInteger(len)||pos<0||len<0||len>MAX_READ||pos+len>size)fail(`out-of-range or oversized pread pos=${pos} len=${len}`);let b=Buffer.alloc(len), got=0;while(got<len){let r=await fh.read(b,got,len-got,pos+got);if(!r.bytesRead)fail('short pread');got+=r.bytesRead}return b}
  async block(n){if(!Number.isSafeInteger(n)||n<0||n>=this.sb.blocks)fail(`invalid block ${n}`);return Ext4.pread(this.fh,this.size,n*this.sb.bs,this.sb.bs)}
  async inode(n){const s=this.sb;if(!Number.isInteger(n)||n<1||n>s.inodes)fail(`invalid inode ${n}`);const g=Math.floor((n-1)/s.ipg), idx=(n-1)%s.ipg,d=g*s.descSize;const tbl=u32(s.gdt,d+8)+(s.is64?u32(s.gdt,d+40)*2**32:0);const raw=await Ext4.pread(this.fh,this.size,tbl*s.bs+idx*s.inodeSize,s.inodeSize);const mode=u16(raw,0),flags=u32(raw,32),size=u32(raw,4)+((mode&0xf000)===0x8000?u32(raw,108)*2**32:0);if(size>Number.MAX_SAFE_INTEGER)fail('unsafe inode size');return {n,raw,mode,kind:typeName(mode),flags,size,links:u16(raw,26)} }
  async extents(inode){if(!(inode.flags&EXT4_EXTENTS_FL))fail(`inode ${inode.n} lacks extents; unsupported`);const out=[];const walk=async(node,depth,base)=>{if(node.length<12||u16(node,0)!==0xf30a)fail(`inode ${inode.n}: invalid extent header`);const entries=u16(node,2),max=u16(node,4),actualDepth=u16(node,6);if(entries>max||actualDepth!==depth||depth>MAX_EXTENT_DEPTH)fail(`inode ${inode.n}: invalid extent tree`);if(12+entries*12>node.length)fail(`inode ${inode.n}: truncated extent entries`);for(let i=0;i<entries;i++){let o=12+i*12,lblock=u32(node,o);if(depth){let child=u32(node,o+4)+u16(node,o+8)*2**32;if(child>=this.sb.blocks)fail(`inode ${inode.n}: child extent block out of range`);await walk(await this.block(child),depth-1,lblock)}else{let len=u16(node,o+4),uninit=Boolean(len&0x8000);len&=0x7fff;let start=u32(node,o+8)+u16(node,o+6)*2**32;if(!len||uninit||start+len>this.sb.blocks)fail(`inode ${inode.n}: unsupported uninitialized/invalid extent`);out.push({lblock, len, start})}}};await walk(inode.raw.subarray(40,100),u16(inode.raw,46),0);out.sort((a,b)=>a.lblock-b.lblock);for(let i=1;i<out.length;i++)if(out[i-1].lblock+out[i-1].len>out[i].lblock)fail(`inode ${inode.n}: overlapping extents`);return out}
  async readInode(inode,offset=0,length=inode.size){if(offset<0||length<0||offset+length>inode.size||length>MAX_FILE)fail(`inode ${inode.n}: invalid/too-large requested read`);let es=await this.extents(inode), bs=this.sb.bs, chunks=[],left=length,p=offset;while(left){let lb=Math.floor(p/bs),inb=p%bs,e=es.find(x=>lb>=x.lblock&&lb<x.lblock+x.len);if(!e)fail(`inode ${inode.n}: sparse/hole block ${lb} unsupported`);let take=Math.min(left,bs-inb);let data=await Ext4.pread(this.fh,this.size,(e.start+lb-e.lblock)*bs+inb,take);chunks.push(data);p+=take;left-=take}return Buffer.concat(chunks)}
  async entries(dir){if(dir.kind!=='directory')fail(`inode ${dir.n} is not directory`);let b=await this.readInode(dir,0,dir.size),o=0,a=[];while(o<b.length){if(o+8>b.length)fail(`inode ${dir.n}: truncated directory entry`);let ino=u32(b,o),rec=u16(b,o+4),nl=b[o+6],ft=b[o+7];if(rec<8||rec%4||o+rec>b.length||nl>rec-8)fail(`inode ${dir.n}: invalid directory record at ${o}`);if(ino){if(ino>this.sb.inodes)fail(`inode ${dir.n}: entry inode out of range`);a.push({name:b.subarray(o+8,o+8+nl).toString('utf8'),inode:ino,fileType:ft,offset:o})}o+=rec}return a}
  async resolve(p){if(typeof p!=='string'||!p.startsWith('/'))fail('path must be absolute');let cur=await this.inode(2);for(const part of p.split('/').filter(Boolean)){if(part==='.'||part==='..'||part.includes('\0'))fail('unsafe path component');let e=(await this.entries(cur)).find(x=>x.name===part);if(!e)fail(`not found: ${p}`);cur=await this.inode(e.inode)}return cur}
  summary(){let s=this.sb;return {blockSize:s.bs,inodeSize:s.inodeSize,blocks:s.blocks,groups:s.groups,inodes:s.inodes,features:{compat:`0x${s.compat.toString(16)}`,incompat:`0x${s.incompat.toString(16)}`,roCompat:`0x${s.ro.toString(16)}`},metadataChecksumPresent:Boolean(s.ro&0x400),uuid:s.uuid}}
  async close(){await this.fh.close()}
}
async function main(){let [cmd,image,p,arg]=process.argv.slice(2);if(!cmd||!image||!p||!['list','stat','read','sha256'].includes(cmd))fail('usage: ext4_read.mjs <list|stat|read|sha256> IMAGE ABSOLUTE_PATH [OUTPUT_FILE for read]');let e=await Ext4.open(image);try{let n=await e.resolve(p);if(cmd==='stat')json({filesystem:e.summary(),path:p,inode:n.n,kind:n.kind,mode:`0${n.mode.toString(8)}`,size:n.size,flags:`0x${n.flags.toString(16)}`,links:n.links,extents:await e.extents(n)});else if(cmd==='list')json({filesystem:e.summary(),path:p,inode:n.n,entries:await e.entries(n)});else {if(n.kind!=='regular')fail('read/sha256 require a regular file');if(n.size>MAX_FILE)fail(`refusing file larger than ${MAX_FILE} bytes`);let b=await e.readInode(n);if(cmd==='sha256')json({filesystem:e.summary(),path:p,inode:n.n,size:n.size,sha256:crypto.createHash('sha256').update(b).digest('hex')});else {if(!arg)fail('read requires explicit OUTPUT_FILE; input image remains read-only');await fs.writeFile(arg,b,{flag:'wx'});json({path:p,inode:n.n,size:n.size,output:arg,sha256:crypto.createHash('sha256').update(b).digest('hex')})}}}finally{await e.close()}}
main().catch(e=>{console.error(`ext4_read: ${e.message}`);process.exitCode=1});
