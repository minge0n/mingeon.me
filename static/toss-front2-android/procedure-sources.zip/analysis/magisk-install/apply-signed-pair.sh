#!/system/bin/sh
set -eu
umask 077
B=/data/local/tmp/aside-magisk-apply
S=/data/adb/aside-magisk-backup/apply-state.txt
I=/dev/block/by-name/init_boot_b
V=/dev/block/by-name/vbmeta_b
file_sha256() { sha256sum "$1" | cut -d ' ' -f 1; }
[ "$(id -u)" = 0 ]
[ "$(getprop ro.boot.slot_suffix)" = _b ]
[ "$(readlink -f "$I")" = /dev/block/sde58 ]
[ "$(readlink -f "$V")" = /dev/block/sde62 ]
[ "$(blockdev --getsize64 "$I")" = 8388608 ]
[ "$(blockdev --getsize64 "$V")" = 65536 ]
[ "$(blockdev --getro "$I")" = 0 ]
[ "$(blockdev --getro "$V")" = 0 ]
[ "$(file_sha256 "$B/init_boot.signed.img")" = 791fd178a9ff132442ee5f515daa26755adb7999c8a589752144d633fb7b8e14 ]
[ "$(file_sha256 "$B/vbmeta.signed.img")" = e3871ddd06dcba6754df4a31c89ee1654139907684846da41e4417fe4ad1a915 ]
[ "$(file_sha256 "$B/init_boot.original.img")" = 34858d31921a7a1e80cc2c4a5656db2af98de37343bd4bc67f2c536fa12b5ee4 ]
[ "$(file_sha256 "$B/vbmeta.original.img")" = 8f3f3e0e0728dd61b3b1473a4a14bd3c3c73d2344b659c92952e5986ed558379 ]
[ "$(file_sha256 "$I")" = 34858d31921a7a1e80cc2c4a5656db2af98de37343bd4bc67f2c536fa12b5ee4 ]
[ "$(file_sha256 "$V")" = 8f3f3e0e0728dd61b3b1473a4a14bd3c3c73d2344b659c92952e5986ed558379 ]
STARTED=0
cleanup() {
  RC=$?
  trap - EXIT
  if [ "$RC" != 0 ] && [ "$STARTED" = 1 ]; then
    set +e
    echo APPLY_FAILED_RESTORING >"$S"
    dd if="$B/init_boot.original.img" of="$I" bs=4096 count=2048 conv=fsync
    dd if="$B/vbmeta.original.img" of="$V" bs=4096 count=16 conv=fsync
    sync
    if [ "$(file_sha256 "$I")" = 34858d31921a7a1e80cc2c4a5656db2af98de37343bd4bc67f2c536fa12b5ee4 ] && [ "$(file_sha256 "$V")" = 8f3f3e0e0728dd61b3b1473a4a14bd3c3c73d2344b659c92952e5986ed558379 ]; then
      echo ROLLBACK_VERIFIED >"$S"
    else
      echo ROLLBACK_FAILED_DO_NOT_REBOOT >"$S"
    fi
  fi
  exit "$RC"
}
trap cleanup EXIT
STARTED=1
echo WRITING_INIT_BOOT >"$S"
dd if="$B/init_boot.signed.img" of="$I" bs=4096 count=2048 conv=fsync
[ "$(file_sha256 "$I")" = 791fd178a9ff132442ee5f515daa26755adb7999c8a589752144d633fb7b8e14 ]
echo WRITING_VBMETA >"$S"
dd if="$B/vbmeta.signed.img" of="$V" bs=4096 count=16 conv=fsync
[ "$(file_sha256 "$V")" = e3871ddd06dcba6754df4a31c89ee1654139907684846da41e4417fe4ad1a915 ]
sync
echo VERIFIED_PENDING_REBOOT >"$S"
STARTED=0
trap - EXIT
exit 0
