#!/system/bin/sh
umask 077
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done
if pidof aside.keepawake >/dev/null 2>&1; then
    exit 0
fi
CLASSPATH=/data/adb/aside-keepawake/keepawake.jar /system/bin/app_process /system/bin --nice-name=aside.keepawake io.aside.keepawake.KeepAwake </dev/null >>/data/adb/aside-keepawake/keepawake.log 2>&1 &
