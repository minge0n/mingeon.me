import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = '/path/to/toss-front2';
const backup = path.join(root, 'backups/20261102-193800-stock');
const outDir = path.join(root, 'images/prepared-gsi');
const source = path.join(backup, 'raw/ufs.bin.lun0');
const manifest = JSON.parse(fs.readFileSync(path.join(backup, 'manifest.json'), 'utf8'));
const superPart = manifest.partitions.find(x => x.name === 'super');
const extracted = JSON.parse(fs.readFileSync(path.join(backup, 'analysis/logical-slot-b/extraction-manifest.json'), 'utf8'));
const readyPath = path.join(outDir, 'system-ready.json');
const gsiPath = path.join(outDir, 'system_b.img');
const output = path.join(outDir, 'super.img');
const layoutOut = path.join(outDir, 'super-layout.json');
const reportOut = path.join(outDir, 'super-build-report.json');
const CHUNK = 8 * 1024 * 1024;
const sha = b => crypto.createHash('sha256').update(b).digest();
const hex = b => sha(b).toString('hex');
const u64 = (b, o) => Number(b.readBigUInt64LE(o));
const put64 = (b, o, n) => b.writeBigUInt64LE(BigInt(n), o);
const need = (ok, message) => { if (!ok) throw Error(message); };
const copyName = b => b.toString('ascii').replace(/\0.*$/s, '');
function hashFile(file, limit) { const fd = fs.openSync(file, 'r'); const h = crypto.createHash('sha256'); const buf = Buffer.alloc(CHUNK); try { let done = 0; while (done < limit) { const n = fs.readSync(fd, buf, 0, Math.min(buf.length, limit - done), done); need(n > 0, 'short hash read'); h.update(buf.subarray(0, n)); done += n; } return h.digest('hex'); } finally { fs.closeSync(fd); } }
function fullRead(fd, b, pos) { let n = 0; while (n < b.length) { const got = fs.readSync(fd, b, n, b.length - n, pos + n); need(got > 0, 'short read'); n += got; } }
function fullWrite(fd, b, pos) { let n = 0; while (n < b.length) { const wrote = fs.writeSync(fd, b, n, b.length - n, pos + n); need(wrote > 0, 'short write'); n += wrote; } }
function streamCopy(inFd, outFd, inPos, outPos, bytes, hash) { const b = Buffer.alloc(CHUNK); let done = 0; while (done < bytes) { const n = Math.min(b.length, bytes - done); fullRead(inFd, b.subarray(0, n), inPos + done); fullWrite(outFd, b.subarray(0, n), outPos + done); hash?.update(b.subarray(0, n)); done += n; } }
function rangeHash(fd, pos, bytes) { const h = crypto.createHash('sha256'), b = Buffer.alloc(CHUNK); let done = 0; while (done < bytes) { const n = Math.min(b.length, bytes - done); fullRead(fd, b.subarray(0, n), pos + done); h.update(b.subarray(0, n)); done += n; } return h.digest('hex'); }
function parseGeometry(fd) { const b = Buffer.alloc(4096); fullRead(fd, b, superPart.offsetBytes + 4096); need(b.readUInt32LE(0) === 0x616c4467, 'bad geometry magic'); const size = b.readUInt32LE(4); const c = Buffer.from(b.subarray(0, size)); c.fill(0, 8, 40); need(sha(c).equals(b.subarray(8, 40)), 'bad geometry checksum'); return { raw: b, size, metadataMax: b.readUInt32LE(40), slots: b.readUInt32LE(44), blockSize: b.readUInt32LE(48) }; }
function parseMetadata(fd, g, slot) { const pos = superPart.offsetBytes + 12288 + slot * g.metadataMax; const b = Buffer.alloc(g.metadataMax); fullRead(fd, b, pos); need(b.readUInt32LE(0) === 0x414c5030 && b.readUInt16LE(4) === 10 && b.readUInt16LE(6) === 2, 'bad slot metadata'); const hs = b.readUInt32LE(8), ts = b.readUInt32LE(44); need(hs === 256 && hs + ts <= b.length, 'unexpected metadata sizes'); const hc = Buffer.from(b.subarray(0, hs)); hc.fill(0, 12, 44); need(sha(hc).equals(b.subarray(12, 44)), 'bad header hash'); need(sha(b.subarray(hs, hs + ts)).equals(b.subarray(48, 80)), 'bad table hash'); const table = (o, min) => { const start=b.readUInt32LE(o), count=b.readUInt32LE(o+4), size=b.readUInt32LE(o+8); need(size >= min && start + count * size <= ts, 'bad table bounds'); return {start,count,size, records:Array.from({length:count}, (_,i)=>Buffer.from(b.subarray(hs+start+i*size, hs+start+(i+1)*size)))}; };
 const partitions=table(80,52), extents=table(92,24), groups=table(104,48), devices=table(116,64);
 return { b, hs, ts, partitions, extents, groups, devices, flags:b.readUInt32LE(128) };
}
function partitionInfo(m) { const groups=m.groups.records.map(r=>copyName(r.subarray(0,36))); return m.partitions.records.map((r,i)=>({i,raw:r,name:copyName(r.subarray(0,36)),attrs:r.readUInt32LE(36),first:r.readUInt32LE(40),count:r.readUInt32LE(44),group:r.readUInt32LE(48),groupName:groups[r.readUInt32LE(48)]})); }
function extentInfo(raw) { return {sectors:u64(raw,0),type:raw.readUInt32LE(8),target:u64(raw,12),device:raw.readUInt32LE(20)}; }
function intervals(parts, m) { return parts.flatMap(p => m.extents.records.slice(p.first,p.first+p.count).map(extentInfo)).filter(e=>e.type===0).map(e=>[e.target,e.target+e.sectors]).sort((a,b)=>a[0]-b[0]); }
function overlap(ranges) { let end=-1; for (const [a,b] of [...ranges].sort((x,y)=>x[0]-y[0])) { if (a < end) return true; end=Math.max(end,b); } return false; }
function encodeMetadata(m, parts, newExtents, keptGroups) { const tables = []; let off=0; const add=(records,size)=>{ const start=off; const b=Buffer.alloc(records.length*size); records.forEach((r,i)=>r.copy(b,i*size)); tables.push(b); off+=b.length; return {start,count:records.length,size}; };
 const p=add(parts.map(x=>x.raw),m.partitions.size), e=add(newExtents,m.extents.size), g=add(keptGroups,m.groups.size), d=add(m.devices.records,m.devices.size);
 const out=Buffer.alloc(m.hs+off); m.b.copy(out,0,0,m.hs); out.writeUInt32LE(off,44); [[80,p],[92,e],[104,g],[116,d]].forEach(([at,x])=>{out.writeUInt32LE(x.start,at);out.writeUInt32LE(x.count,at+4);out.writeUInt32LE(x.size,at+8);}); for (let i=0, pos=m.hs;i<tables.length;i++){tables[i].copy(out,pos);pos+=tables[i].length;} sha(out.subarray(m.hs)).copy(out,48); const h=Buffer.from(out.subarray(0,m.hs)); h.fill(0,12,44); sha(h).copy(out,12); return out;
}
function validateReady() {
  need(fs.existsSync(readyPath), 'PARENT_NOT_READY');
  const ready=JSON.parse(fs.readFileSync(readyPath));
  need(ready.fullPreparedAVBChainVerified===true && ready.topLevelVbmetaUnchanged===true,'AVB chain readiness missing');
  const st=fs.lstatSync(gsiPath), vpath=path.join(outDir,'vbmeta_system_b.img'), vst=fs.lstatSync(vpath);
  need(st.isFile()&&st.size===ready.systemImage.bytes&&st.size%4096===0,'GSI size/regular-file mismatch');
  need(vst.isFile()&&vst.size===65536&&vst.size===ready.vbmetaSystem.bytes,'vbmeta size mismatch');
  const digest=hashFile(gsiPath,st.size);
  need(digest===ready.systemImage.sha256,'GSI hash does not match AVB-verified input');
  need(hashFile(vpath,vst.size)===ready.vbmetaSystem.sha256,'vbmeta hash differs from AVB-verified input');
  return {ready,size:st.size,sha256:digest};
}
function validateExtents(es,first,sectors,label) {
  for(const e of es)need(e.type===0&&e.device===0&&e.sectors>0&&e.target>=first&&e.target+e.sectors<=sectors&&e.target%8===0&&e.sectors%8===0,label+': invalid extent');
}
function decodeCandidate(b,g) {
  need(b.readUInt32LE(0)===0x414c5030&&b.readUInt16LE(4)===10&&b.readUInt16LE(6)===2,'candidate magic/version');
  const hs=b.readUInt32LE(8),ts=b.readUInt32LE(44);need(hs===256&&hs+ts<=g.metadataMax,'candidate sizes');
  const h=Buffer.from(b.subarray(0,hs));h.fill(0,12,44);need(sha(h).equals(b.subarray(12,44)),'candidate header SHA');
  need(sha(b.subarray(hs,hs+ts)).equals(b.subarray(48,80)),'candidate table SHA');
  const occupied=[];
  const table=(o,expected)=>{const start=b.readUInt32LE(o),count=b.readUInt32LE(o+4),size=b.readUInt32LE(o+8);need(size===expected&&start+count*size<=ts,'candidate table range');occupied.push([start,start+count*size]);return Array.from({length:count},(_,i)=>Buffer.from(b.subarray(hs+start+i*size,hs+start+(i+1)*size)));};
  const partitions=table(80,52),extents=table(92,24),groups=table(104,48),devices=table(116,64);
  need(!overlap(occupied),'candidate metadata tables overlap');
  return {partitions,extents,groups,devices,flags:b.readUInt32LE(128)};
}
function hashLogical(fd,es) {
  const h=crypto.createHash('sha256'),buf=Buffer.alloc(CHUNK);
  for(const e of es){let done=0,bytes=e.sectors*512;while(done<bytes){const n=Math.min(buf.length,bytes-done);fullRead(fd,buf.subarray(0,n),e.target*512+done);h.update(buf.subarray(0,n));done+=n;}}
  return h.digest('hex');
}
const created=new Map();
function createExclusive(p) {const fd=fs.openSync(p,fs.constants.O_WRONLY|fs.constants.O_CREAT|fs.constants.O_EXCL|(fs.constants.O_NOFOLLOW||0),0o600);const s=fs.fstatSync(fd);created.set(p,{dev:s.dev,ino:s.ino});return fd;}
function writeNewJson(p,obj){const fd=createExclusive(p);try{fullWrite(fd,Buffer.from(JSON.stringify(obj,null,2)+'\n'),0);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
function cleanOwned() {for(const[p,id]of created){try{const s=fs.lstatSync(p);if(s.dev===id.dev&&s.ino===id.ino&&s.isFile())fs.unlinkSync(p);}catch(e){if(e.code!=='ENOENT')console.error('Cleanup:',e.message);}}}
function main(){
 let srcFd=null,outFd=null,verifyFd=null,complete=false;
 try{
  const gsi=validateReady();
  for(const p of[output,layoutOut,reportOut])need(!fs.existsSync(p),'Existing candidate output: '+p);
  const st=fs.lstatSync(source);need(st.isFile()&&st.size>=superPart.offsetBytes+superPart.sizeBytes,'Invalid immutable source file');
  const sourceSha=hashFile(source,st.size);need(sourceSha===manifest.luns.find(l=>l.lun===0).sha256,'Raw source manifest hash mismatch');
  srcFd=fs.openSync(source,'r');
  const geom=parseGeometry(srcFd);need(geom.metadataMax===65536&&geom.slots===3&&geom.blockSize===4096,'Unexpected geometry');
  const backupGeometry=Buffer.alloc(4096);fullRead(srcFd,backupGeometry,superPart.offsetBytes+8192);need(backupGeometry.equals(geom.raw),'Source geometry copies differ');
  const meta=parseMetadata(srcFd,geom,1);need(meta.devices.count===1,'Only a single super device is supported');
  need(meta.partitions.size===52&&meta.extents.size===24&&meta.groups.size===48&&meta.devices.size===64,'Unexpected metadata record sizes');
  const dev=meta.devices.records[0],first=u64(dev,0),devBytes=u64(dev,16),last=devBytes/512;
  need(first===2048&&devBytes===5368709120&&devBytes===superPart.sizeBytes,'Unexpected super device bounds');
  const all=partitionInfo(meta);need(new Set(all.map(p=>p.name)).size===all.length,'Duplicate source partition names');
  for(const p of all){need(p.first+p.count<=meta.extents.count&&p.group<meta.groups.count,'Source table reference out of bounds');validateExtents(meta.extents.records.slice(p.first,p.first+p.count).map(extentInfo),first,last,p.name);}
  const retainNames=['odm_b','product_b','system_dlkm_b','vendor_b','vendor_dlkm_b'];
  const retained=retainNames.map(n=>{const p=all.find(x=>x.name===n);need(p,'Missing '+n);need(p.groupName==='qti_dynamic_partitions_b','Retained partition group mismatch');return {...p,raw:Buffer.from(p.raw)};});
  const os=all.find(p=>p.name==='system_b');need(os&&os.groupName==='qti_dynamic_partitions_b','Missing B system');
  const system={...os,raw:Buffer.from(os.raw)},bGroupRaw=Buffer.from(meta.groups.records[os.group]);
  need(copyName(meta.groups.records[0].subarray(0,36))==='default','Unexpected default group');
  const retainedRanges=intervals(retained,meta);need(!overlap(retainedRanges),'Retained source extents overlap');
  const free=[];let cursor=first;
  for(const[a,b]of retainedRanges){need(a>=first&&b<=last&&b>a,'Retained range bounds');if(cursor<a)free.push([cursor,a]);cursor=Math.max(cursor,b);}if(cursor<last)free.push([cursor,last]);
  const alignmentSectors=dev.readUInt32LE(8)/512;need(alignmentSectors===1024,'Unexpected source alignment');need(meta.extents.records.slice(os.first,os.first+os.count).map(extentInfo).every(e=>e.target%alignmentSectors===0),'Source system uses different extent alignment phase');
  const alloc=[];let left=gsi.size/512;
  for(const[a,b]of free){const start=Math.ceil(a/alignmentSectors)*alignmentSectors,capacity=Math.floor((b-start)/8)*8,take=Math.min(left,capacity);if(take>0){alloc.push([start,take]);left-=take;}if(left===0)break;}
  need(left===0,'Insufficient preserved-data-safe space');need(!overlap([...retainedRanges,...alloc.map(([s,n])=>[s,s+n])]),'GSI/retained extent overlap');
  system.raw.writeUInt32LE(1,36);
  const parts=[...retained,system].sort((a,b)=>a.i-b.i),newExtents=[];
  for(const p of parts){const firstIndex=newExtents.length;if(p.name==='system_b'){for(const[target,sectors]of alloc){const r=Buffer.alloc(24);put64(r,0,sectors);r.writeUInt32LE(0,8);put64(r,12,target);r.writeUInt32LE(0,20);newExtents.push(r);}}else{newExtents.push(...meta.extents.records.slice(p.first,p.first+p.count).map(r=>Buffer.from(r)));}p.raw.writeUInt32LE(firstIndex,40);p.raw.writeUInt32LE(newExtents.length-firstIndex,44);p.raw.writeUInt32LE(1,48);}
  const physical=newExtents.map(extentInfo);validateExtents(physical,first,last,'Planned candidate');need(!overlap(physical.map(e=>[e.target,e.target+e.sectors])),'Planned extents overlap');
  const used=physical.reduce((n,e)=>n+e.sectors*512,0),max=u64(bGroupRaw,40);need(!max||used<=max,'Group maximum exceeded');
  const metadata=encodeMetadata(meta,parts,newExtents,[Buffer.from(meta.groups.records[0]),bGroupRaw]);need(metadata.length<=geom.metadataMax,'Metadata does not fit');
  const primary=12288+geom.metadataMax,backupOffset=12288+geom.slots*geom.metadataMax+geom.metadataMax;
  need(primary+geom.metadataMax<=first*512&&backupOffset+geom.metadataMax<=first*512,'Metadata overlaps data area');
  console.log('Input checks passed; copying immutable source super range.');
  outFd=createExclusive(output);const sourceSuperHasher=crypto.createHash('sha256');streamCopy(srcFd,outFd,superPart.offsetBytes,0,devBytes,sourceSuperHasher);
  const sourceSuperSha=sourceSuperHasher.digest('hex'),slot=Buffer.alloc(geom.metadataMax);metadata.copy(slot);fullWrite(outFd,slot,primary);fullWrite(outFd,slot,backupOffset);
  const gfd=fs.openSync(gsiPath,'r');try{let pos=0;for(const[s,n]of alloc){streamCopy(gfd,outFd,pos,s*512,n*512);pos+=n*512;}need(pos===gsi.size,'GSI placement size');}finally{fs.closeSync(gfd);}
  fs.fsyncSync(outFd);fs.closeSync(outFd);outFd=null;console.log('Candidate written locally; independently decoding candidate metadata and payloads.');
  need(fs.statSync(output).size===devBytes,'Candidate file size');verifyFd=fs.openSync(output,'r');
  const raw=Buffer.alloc(geom.metadataMax),back=Buffer.alloc(geom.metadataMax);fullRead(verifyFd,raw,primary);fullRead(verifyFd,back,backupOffset);need(raw.equals(back),'Candidate metadata copies differ');
  const c=decodeCandidate(raw,geom);need(c.flags===meta.flags,'Header flags changed');need(c.devices.length===1&&c.devices[0].equals(dev),'Physical-device geometry changed');
  need(c.groups.length===2&&c.groups[0].equals(meta.groups.records[0])&&c.groups[1].equals(bGroupRaw),'Candidate groups changed unexpectedly');
  const cparts=c.partitions.map(r=>({name:copyName(r.subarray(0,36)),attrs:r.readUInt32LE(36),first:r.readUInt32LE(40),count:r.readUInt32LE(44),group:r.readUInt32LE(48)}));
  need(JSON.stringify(cparts.map(p=>p.name))===JSON.stringify(parts.map(p=>p.name)),'Candidate partition set/order');
  const cext=c.extents.map(extentInfo);validateExtents(cext,first,last,'Decoded candidate');need(!overlap(cext.map(e=>[e.target,e.target+e.sectors])),'Decoded candidate extents overlap');
  const usedIndices=new Set(),retainedReport=[];
  for(const p of cparts){need(p.group===1&&p.first+p.count<=cext.length,'Decoded extent reference');for(let i=p.first;i<p.first+p.count;i++){need(!usedIndices.has(i),'Duplicate extent reference');usedIndices.add(i);}const es=cext.slice(p.first,p.first+p.count),bytes=es.reduce((n,e)=>n+e.sectors*512,0),digest=hashLogical(verifyFd,es);
   if(p.name==='system_b'){need(p.attrs===1&&bytes===gsi.size&&digest===gsi.sha256,'Decoded system mapping/hash mismatch');need(es.every(e=>e.target%alignmentSectors===0),'New system start alignment differs from working source');}
   else{const original=all.find(x=>x.name===p.name),expected=extracted.images.find(x=>x.name===p.name);need(original&&expected&&p.attrs===original.attrs,'Retained metadata identity');need(bytes===expected.bytes&&digest===expected.sha256,p.name+': decoded logical payload mismatch');const originalEs=meta.extents.records.slice(original.first,original.first+original.count).map(extentInfo);need(JSON.stringify(es)===JSON.stringify(originalEs),'Retained physical mapping changed');retainedReport.push({name:p.name,bytes,sha256:digest});}
  }
  need(usedIndices.size===cext.length,'Unreferenced candidate extents');
  const allowed=[[primary,primary+geom.metadataMax],[backupOffset,backupOffset+geom.metadataMax],...alloc.map(([s,n])=>[s*512,(s+n)*512])].sort((a,b)=>a[0]-b[0]);need(!overlap(allowed),'Allowed modification ranges overlap');
  let at=0,compared=0;for(const[a,b]of [...allowed,[devBytes,devBytes]]){if(at<a){const len=a-at;need(rangeHash(srcFd,superPart.offsetBytes+at,len)===rangeHash(verifyFd,at,len),'Bytes outside approved candidate ranges changed');compared+=len;}at=Math.max(at,b);}
  const after=fs.statSync(source);need(after.dev===st.dev&&after.ino===st.ino&&after.size===st.size&&after.mtimeMs===st.mtimeMs,'Source inode or modification time changed');
  need(hashFile(source,st.size)===sourceSha,'Immutable source hash changed');
  const report={createdAt:new Date().toISOString(),source,sourceSha256:sourceSha,sourceSuperSha256:sourceSuperSha,sourceUnchanged:true,superSizeBytes:devBytes,superSha256:hashFile(output,devBytes),gsi:{path:gsiPath,bytes:gsi.size,sha256:gsi.sha256},retained:retainedReport,removed:['system_ext_b','all *-cow partitions','cow group'],slot1:{headerFlags:c.flags,primaryOffset:primary,backupOffset,identical:true},allocation:alloc.map(([sector,sectors])=>({sector,sectors,bytes:sectors*512})),verification:{preparedAvbInputHashesMatched:true,newSystemStartAlignmentBytes:alignmentSectors*512,alignmentOffsetPreserved:dev.readUInt32LE(12),metadataChecksums:true,decodedMetadataLogicalHashes:true,tableBounds:true,physicalExtentUnoverlap:true,retainedPhysicalMappingPreserved:true,bytesOutsidePlannedRangesPreserved:true,unchangedBytesCompared:compared,geometryAndSlots0And2Preserved:true},limitations:['Offline candidate; modified GSI boot not yet tested','Shared super means original stock A OS bootability not preserved']};
  writeNewJson(layoutOut,{geometry:{metadataMaxSize:geom.metadataMax,metadataSlotCount:geom.slots,logicalBlockSize:geom.blockSize},slot:1,partitions:cparts.map(p=>({name:p.name,attributes:p.attrs,group:'qti_dynamic_partitions_b',sizeBytes:cext.slice(p.first,p.first+p.count).reduce((n,e)=>n+e.sectors*512,0),extents:cext.slice(p.first,p.first+p.count)})),allocation:report.allocation});
  writeNewJson(reportOut,report);complete=true;console.log(JSON.stringify(report,null,2));
 }finally{if(verifyFd!==null)fs.closeSync(verifyFd);if(outFd!==null)fs.closeSync(outFd);if(srcFd!==null)fs.closeSync(srcFd);if(!complete)cleanOwned();}
}
try{main();}catch(e){console.error(e.stack||e.message);process.exitCode=1;}
